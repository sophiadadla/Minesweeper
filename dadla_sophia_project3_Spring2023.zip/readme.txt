Name: Sophia Dadla
Section: 10861
UFL email: dadlas@ufl.edu
System: Windows 64-bit
Compiler: MinGW
SFML version: 2.5.1
IDE: CLion
Other notes: 